<link rel="stylesheet" href="assets/css/popup_style.css">
<style>
.footer1 {
  position: fixed;
  bottom: 0;
  width: 100%;
  color: #5c4ac7;
  text-align: center;
}

/* New Beautiful Styles */
.unix-login {
  background: linear-gradient(135deg, rgba(102, 126, 234, 0.7) 0%, rgba(118, 75, 162, 0.7) 100%), 
              url('backgroundimg.jpg') center/cover no-repeat;
  min-height: 100vh;
  display: flex;
  align-items: center;
}
.login-content.card {
  border: none;
  border-radius: 10px;
  box-shadow: 0 15px 30px rgba(0,0,0,0.1);
  overflow: hidden;
  transition: all 0.3s ease;
}

.login-content.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 20px 40px rgba(0,0,0,0.15);
}

.login-form {
  padding: 40px;
}

.login-form h4 {
  color: #5c4ac7;
  text-align: center;
  margin-bottom: 30px;
  font-weight: 600;
}

.form-control {
  border: 1px solid #e0e0e0;
  border-radius: 5px;
  padding: 12px 15px;
  margin-bottom: 20px;
  transition: all 0.3s;
}

.form-control:focus {
  border-color: #5c4ac7;
  box-shadow: 0 0 0 2px rgba(92,74,199,0.2);
}

.btn-primary {
  background-color: #5c4ac7;
  border: none;
  padding: 12px;
  border-radius: 5px;
  font-weight: 500;
  letter-spacing: 0.5px;
  transition: all 0.3s;
  width: 100%;
}

.btn-primary:hover {
  background-color: #4a3ab5;
  transform: translateY(-2px);
}

.forgot-phone a {
  color: #888;
  transition: color 0.3s;
}

.forgot-phone a:hover {
  color: #5c4ac7;
  text-decoration: none;
}

/* Logo styling */
.login-logo {
  text-align: center;
  margin-bottom: 30px;
}

.login-logo img {
  max-width: 120px;
  height: auto;
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .login-form {
    padding: 30px 20px;
  }
}
</style>

<?php
include('./constant/layout/head.php');
include('./constant/connect.php');
session_start();

if(isset($_SESSION['userId'])) {
 //header('location:'.$store_url.'login.php');   
}

$errors = array();

if($_POST) {    
  $username = $_POST['username'];
  $password = $_POST['password'];

  if(empty($username) || empty($password)) {
    if($username == "") {
      $errors[] = "Username is required";
    } 
    if($password == "") {
      $errors[] = "Password is required";
    }
  } else {
    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = $connect->query($sql);

    if($result->num_rows == 1) {
      $password = md5($password);
      $mainSql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
      $mainResult = $connect->query($mainSql);

      if($mainResult->num_rows == 1) {
        $value = $mainResult->fetch_assoc();
        $user_id = $value['user_id'];
        $_SESSION['userId'] = $user_id;?>
      
        <div class="popup popup--icon -success js_success-popup popup--visible">
          <div class="popup__background"></div>
          <div class="popup__content">
            <h3 class="popup__content__title">Success</h1>
            <p>Login Successfully</p>
            <p><?php echo "<script>setTimeout(\"location.href = 'dashboard.php';\",1500);</script>"; ?></p>
          </div>
        </div>
      <?php } else { ?>
        <div class="popup popup--icon -error js_error-popup popup--visible">
          <div class="popup__background"></div>
          <div class="popup__content">
            <h3 class="popup__content__title">Error</h1>
            <p>Incorrect username/password combination</p>
            <p><a href="login.php"><button class="button button--error" data-for="js_error-popup">Close</button></a></p>
          </div>
        </div>
      <?php } 
    } else { ?> 
      <div class="popup popup--icon -error js_error-popup popup--visible">
        <div class="popup__background"></div>
        <div class="popup__content">
          <h3 class="popup__content__title">Error</h1>
          <p>Username does not exist</p>
          <p><a href="login.php"><button class="button button--error" data-for="js_error-popup">Close</button></a></p>
        </div>
      </div>  
    <?php } 
  } 
} 
?>

<div id="main-wrapper">
  <div class="unix-login">
    <div class="container-fluid">
      <div class="row justify-content-center">
        <div class="col-lg-4">
          <div class="login-content card">
            <!-- <div class="login-logo">
              <img src="./assets/uploadImage/Logo/.jpg" alt="Company Logo">
            </div> -->
            <div class="login-form">
              <h4>Welcome Back</h4>
              <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" id="loginForm">
                <div class="form-group">
                  <label>Username</label>
                  <input type="text" name="username" id="username" class="form-control" placeholder="Enter your username" required>
                </div>
                <div class="form-group">
                  <label>Password</label>
                  <input type="password" id="password" name="password" class="form-control" placeholder="Enter your password" required>
                </div>
                <button type="submit" name="login" class="btn btn-primary btn-flat m-b-30 m-t-30">Sign In</button>
                <div class="forgot-phone text-right f-right">
                  <a href="#" class="text-right f-w-600">Forgot Password?</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="./assets/js/lib/jquery/jquery.min.js"></script>
<script src="./assets/js/lib/bootstrap/js/popper.min.js"></script>
<script src="./assets/js/lib/bootstrap/js/bootstrap.min.js"></script>
<script src="./assets/js/jquery.slimscroll.js"></script>
<script src="./assets/js/sidebarmenu.js"></script>
<script src="./assets/js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>
<script src="./assets/js/custom.min.js"></script>
</body>
</html>