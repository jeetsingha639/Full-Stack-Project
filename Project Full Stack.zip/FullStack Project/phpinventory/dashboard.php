<?php error_reporting(1); ?>
<?php include('./constant/layout/head.php');?>
<?php include('./constant/layout/header.php');?>

<?php include('./constant/layout/sidebar.php');?>   
<?php 


$lowStockSql = "SELECT * FROM product WHERE quantity <= 3 AND status = 1";
$lowStockQuery = $connect->query($lowStockSql);
$countLowStock = $lowStockQuery->num_rows;


$connect->close();

?>
  
<style type="text/css">
   
    .dashboard-mockup {
            width: 100%;
            height: 500px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            padding: 20px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .dashboard-title {
            font-size: 24px;
            color: #4e73df;
            font-weight: bold;
        }
        .dashboard-date {
            color: #6c757d;
        }
        .stats-container {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            flex: 1;
            padding: 20px;
            border-radius: 8px;
            color: white;
            text-align: center;
        }
        .stat-card.primary {
            background: #4e73df;
        }
        .stat-card.warning {
            background: #f6c23e;
        }
        .stat-card.success {
            background: #1cc88a;
        }
        .stat-value {
            font-size: 32px;
            font-weight: bold;
            margin: 10px 0;
        }
        .chart-placeholder {
            height: 200px;
            background: #f8f9fa;
            border-radius: 8px;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #6c757d;
            border: 1px dashed #ddd;
        }
        .recent-orders {
            background: white;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .recent-orders h3 {
            color: #4e73df;
            margin-bottom: 15px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th {
            color: #6c757d;
            font-weight: normal;
        }
</style>
        
        <div class="page-wrapper">
            
            <div class="row page-titles">
                <div class="col-md-12 align-self-center">
                    
                
            </div>
            
            <div class="dashboard-mockup">
        <div class="dashboard-header">
            <div class="dashboard-title">Dashboard</div>
            <div class="dashboard-date">Tuesday 16, 2025</div>
        </div>
        
        <div class="stats-container">
            <div class="stat-card primary">
                <div>Total Products</></div>
                <div class="stat-value">128</div>
                <div>+5% from last month</div>
            </div>
            <div class="stat-card warning">
                <div>Low Stock</div>
                <div class="stat-value">7</div>
                <div>Items need restocking</div>
            </div>
            <div class="stat-card success">
                <div>Total Orders</div>
                <div class="stat-value">42</div>
                <div>This month</div>
            </div>
        </div>
        
        <div class="recent-orders">
            <h3>Recent Orders</h3>
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Customer</th>
                        <th>Date</th>
                        <th>Amount</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>#INV-2025-0015</td>
                        <td>Gulshan</td>
                        <td>Jan 1, 2025</td>
                        <td>$248.19</td>
                        <td>Completed</td>
                    </tr>
                    <tr>
                        <td>#INV-2025-0014</td>
                        <td>Maanav</td>
                        <td>Jan 10, 2025</td>
                        <td>$189.50</td>
                        <td>Shipped</td>
                    </tr>
                    <tr>
                        <td>#INV-2025-0013</td>
                        <td>Abhishek</td>
                        <td>Jan 12, 2025</td>
                        <td>$425.91</td>
                        <td>Processing</td>
                    </tr>
                    <tr>
                        <td>#INV-2025-0012</td>
                        <td>Arjun</td>
                        <td>Feb 3, 2025</td>
                        <td>$411.12</td>
                        <td>Completed</td>
                    </tr>
                    <tr>
                        <td>#INV-2025-0013</td>
                        <td>Rahul</td>
                        <td>Feb 12, 2025</td>
                        <td>$400.00</td>
                        <td>Processing</td>
                    </tr>
                    <tr>
                        <td>#INV-2025-0013</td>
                        <td>Deepesh</td>
                        <td>March 17, 2025</td>
                        <td>$325.23</td>
                        <td>Processing</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>



            
            <?php include ('./constant/layout/footer.php');?>
        <script>
        $(function(){
            $(".preloader").fadeOut();
        })
        </script>